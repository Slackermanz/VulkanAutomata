#include "src/slack_engine.h"

#include <vector>
#include <fstream>
#include <chrono>
#include <thread>

struct UB32_64 { uint32_t u32[64]; };

struct GLFW_mouse {
	GLFWwindow* window;
	double 		xpos;
	double 		ypos;
	int 		button;
	int 		action;
	int 		mods;
	double 		xoffset;
	double 		yoffset; };

GLFW_mouse 	glfw_mouse;

void clear_glfw_mouse(GLFW_mouse *e) {
	e->mods 	= 0;
	e->xoffset 	= 0;
	e->yoffset 	= 0; }

void glfw_mousemove_event(GLFWwindow* window, double xpos, double ypos) {
	glfw_mouse.window 	= window;
	glfw_mouse.xpos		= xpos;
	glfw_mouse.ypos 	= ypos; }

void glfw_mouseclick_event(GLFWwindow* window, int button, int action, int mods) {
	glfw_mouse.window 	= window;
	glfw_mouse.button	= button;
	glfw_mouse.action 	= action;
	glfw_mouse.mods 	= mods; }

void glfw_mousescroll_event(GLFWwindow* window, double xoffset, double yoffset) {
	glfw_mouse.window 	= window;
	glfw_mouse.xoffset	= xoffset;
	glfw_mouse.yoffset 	= yoffset; }


struct ShaderCodeInfo {
	std::string 		shaderFilename;
	std::vector<char>	shaderData;
	size_t 				shaderBytes;
	bool 				shaderBytesValid; };
ShaderCodeInfo getShaderCodeInfo(std::string fname) {
	std::ifstream 		file		(fname, std::ios::ate | std::ios::binary);
	size_t 				fileSize = 	(size_t) file.tellg();
	std::vector<char> 	buffer		(fileSize);
	file.seekg(0);
	file.read(buffer.data(), fileSize);
	file.close();
	ShaderCodeInfo sc_info;
		sc_info.shaderFilename		= fname;
		sc_info.shaderData			= buffer;
		sc_info.shaderBytes			= buffer.size();
		sc_info.shaderBytesValid	= (sc_info.shaderBytes%4==0?1:0);
	return sc_info; }

int32_t findProperties(
	const 		VkPhysicalDeviceMemoryProperties* 	pMemoryProperties,
				uint32_t 							memoryTypeBitsRequirement,
				VkMemoryPropertyFlags 				requiredProperties 			) {
    const 		uint32_t 	memoryCount = pMemoryProperties->memoryTypeCount;
    for ( uint32_t memoryIndex = 0; memoryIndex < memoryCount; ++memoryIndex ) {
        const 	uint32_t 				memoryTypeBits 			= (1 << memoryIndex);
        const 	bool 					isRequiredMemoryType 	= memoryTypeBitsRequirement & memoryTypeBits;
        const 	VkMemoryPropertyFlags 	properties 				= pMemoryProperties->memoryTypes[memoryIndex].propertyFlags;
        const 	bool 					hasRequiredProperties 	= (properties & requiredProperties) == requiredProperties;
        if (isRequiredMemoryType && hasRequiredProperties) { return static_cast<int32_t>(memoryIndex); } } return -1; }

struct NS_Timer {
	std::chrono::_V2::system_clock::time_point st;
	std::chrono::_V2::system_clock::time_point ft;
};

NS_Timer start_timer(NS_Timer t) {
	t.st = std::chrono::high_resolution_clock::now();
	return t; }

void end_timer(NS_Timer t, std::string msg) {
	t.ft = std::chrono::high_resolution_clock::now();
	std::string ftime 	= std::to_string(
		std::chrono::duration_cast<std::chrono::nanoseconds>(t.ft-t.st).count()) + " ns, " +
		std::to_string( int(1000000000.0 / std::chrono::duration_cast<std::chrono::nanoseconds>(t.ft-t.st).count()) ) + " FPS";
	ov(msg, ftime); }

int main() {

	srand(time(0));

	VK_Context vk_ctx;
		engine_vulkan_context_init( &vk_ctx, "SlackAutomata" );

	VK_PhysicalDevice vk_pdv[vk_ctx.pd_count];
		engine_vulkan_get_physical_device( &vk_ctx, vk_pdv );
		show_pd_info( &vk_pdv[vk_ctx.pd_index] );

	VK_QueueFamily vk_qfp[vk_pdv[vk_ctx.pd_index].qf_count];
		engine_vulkan_get_queue_families( &vk_pdv[vk_ctx.pd_index], vk_qfp );
		show_qf_info( &vk_pdv[vk_ctx.pd_index], vk_qfp );

	const uint32_t 	QUEUE_TYPE_COUNT = 3;
	VK_QueueList vk_queue_type_list[QUEUE_TYPE_COUNT];
		engine_vulkan_queue_list_add( &vk_pdv[vk_ctx.pd_index], vk_qfp, &vk_queue_type_list[0], 0, VK_QUEUE_COMPUTE_BIT, VK_QUEUE_GRAPHICS_BIT );
		engine_vulkan_queue_list_add( &vk_pdv[vk_ctx.pd_index], vk_qfp, &vk_queue_type_list[1], 0, VK_QUEUE_COMPUTE_BIT  );
		engine_vulkan_queue_list_add( &vk_pdv[vk_ctx.pd_index], vk_qfp, &vk_queue_type_list[2], 0, VK_QUEUE_GRAPHICS_BIT );

	bool 			use_queue[QUEUE_TYPE_COUNT];
	uint32_t 		queue_list_count = 0;
		engine_vulkan_queue_list_count( QUEUE_TYPE_COUNT, vk_queue_type_list, &queue_list_count, use_queue );

	VK_QueueList vk_queue_list[queue_list_count];
		engine_vulkan_queue_list_select( QUEUE_TYPE_COUNT, vk_queue_type_list, use_queue, vk_queue_list );

	VK_LogicalDevice vk_ldv;
		engine_vulkan_logical_device_init( &vk_pdv[vk_ctx.pd_index], queue_list_count, vk_queue_list, &vk_ldv );

	VK_CommandPool vk_cpl[queue_list_count];
		engine_vulkan_command_pool_init( vk_queue_list, &vk_ldv, vk_cpl );

	ov( "Test queue find ..." );

	uint32_t QFI_compute = UINT32_MAX;
		engine_vulkan_get_queue_family_index( &vk_pdv[vk_ctx.pd_index], vk_qfp, &QFI_compute, VK_QUEUE_COMPUTE_BIT, VK_QUEUE_GRAPHICS_BIT );
		engine_vulkan_get_queue_family_index( &vk_pdv[vk_ctx.pd_index], vk_qfp, &QFI_compute, VK_QUEUE_COMPUTE_BIT );

	uint32_t QLI_compute = UINT32_MAX;
	for(int i = 0; i < queue_list_count; i++) { if( vk_queue_list[i].qf_index == QFI_compute ) { QLI_compute = i; } }

	VK_Command vk_cmd_init = new_vk_command( QFI_compute, vk_cpl[QLI_compute].cp, VK_PIPELINE_BIND_POINT_COMPUTE );
		svk_allocate_command_buffer( &vk_ldv, &vk_cmd_init );

	VK_Command vk_cmd = new_vk_command( QFI_compute, vk_cpl[QLI_compute].cp, VK_PIPELINE_BIND_POINT_COMPUTE );
		svk_allocate_command_buffer( &vk_ldv, &vk_cmd );

	VK_Command vk_cmd2 = new_vk_command( QFI_compute, vk_cpl[QLI_compute].cp, VK_PIPELINE_BIND_POINT_COMPUTE );
		svk_allocate_command_buffer( &vk_ldv, &vk_cmd2 );

	ov( "Test shader load ..." );

//	ShaderCodeInfo sci = getShaderCodeInfo("bin/comp_gather_kernels.spv");
	ShaderCodeInfo sci = getShaderCodeInfo("bin/comp_compare_kernels.spv");

	VkShaderModuleCreateInfo vk_shader_module_compute_info;
		vk_shader_module_compute_info.sType		= VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
		vk_shader_module_compute_info.pNext		= nullptr;
		vk_shader_module_compute_info.flags		= 0;
		vk_shader_module_compute_info.codeSize	= sci.shaderBytes;
		vk_shader_module_compute_info.pCode		= reinterpret_cast<const uint32_t*>(sci.shaderData.data());

	VkShaderModule vk_shader_compute;
	vkCreateShaderModule( vk_ldv.ld, &vk_shader_module_compute_info, nullptr, &vk_shader_compute );

	ov( "Test shader load ..." );

	ShaderCodeInfo sci2 = getShaderCodeInfo("bin/comp_compare_kernels.spv");

	VkShaderModuleCreateInfo vk_shader_module_compute_info2;
		vk_shader_module_compute_info2.sType		= VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
		vk_shader_module_compute_info2.pNext		= nullptr;
		vk_shader_module_compute_info2.flags		= 0;
		vk_shader_module_compute_info2.codeSize		= sci2.shaderBytes;
		vk_shader_module_compute_info2.pCode		= reinterpret_cast<const uint32_t*>(sci2.shaderData.data());

	VkShaderModule vk_shader_compute2;
	vkCreateShaderModule( vk_ldv.ld, &vk_shader_module_compute_info2, nullptr, &vk_shader_compute2 );

	ov( "Test descriptors ..." );

	VkDescriptorSetLayoutBinding dslb[3];

		dslb[0].binding				= 0;
		dslb[0].descriptorType		= VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
		dslb[0].descriptorCount		= 1;
		dslb[0].stageFlags			= VK_SHADER_STAGE_COMPUTE_BIT;
		dslb[0].pImmutableSamplers	= nullptr;

		dslb[1].binding				= 1;
		dslb[1].descriptorType		= VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
		dslb[1].descriptorCount		= 1;
		dslb[1].stageFlags			= VK_SHADER_STAGE_COMPUTE_BIT;
		dslb[1].pImmutableSamplers	= nullptr;

		dslb[2].binding				= 2;
		dslb[2].descriptorType		= VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
		dslb[2].descriptorCount		= 1;
		dslb[2].stageFlags			= VK_SHADER_STAGE_COMPUTE_BIT;
		dslb[2].pImmutableSamplers	= nullptr;

	VkDescriptorSetLayoutCreateInfo dslcinfo;
		dslcinfo.sType			= VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
		dslcinfo.pNext			= nullptr;
		dslcinfo.flags			= 0;
		dslcinfo.bindingCount	= 3;
		dslcinfo.pBindings		= dslb;

	VkDescriptorSetLayout dsl;
	vkCreateDescriptorSetLayout(vk_ldv.ld, &dslcinfo, nullptr, &dsl);

	ov( "Test descriptors ..." );

	VkDescriptorPoolSize vkdps[3];

		vkdps[0].type				= VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
		vkdps[0].descriptorCount	= 1;

		vkdps[1].type				= VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
		vkdps[1].descriptorCount	= 1;

		vkdps[2].type				= VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
		vkdps[2].descriptorCount	= 1;

	VkDescriptorPoolCreateInfo dspinfo;
		dspinfo.sType			= VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
		dspinfo.pNext			= nullptr;
		dspinfo.flags			= 0;
		dspinfo.maxSets			= 1;
		dspinfo.poolSizeCount	= 3;
		dspinfo.pPoolSizes		= vkdps;

	VkDescriptorPool vkdsp;
	vkCreateDescriptorPool(vk_ldv.ld, &dspinfo, nullptr, &vkdsp);

	VkDescriptorPool vkdsp2;
	vkCreateDescriptorPool(vk_ldv.ld, &dspinfo, nullptr, &vkdsp2);

	VkDescriptorSetAllocateInfo vkdsainfo;
		vkdsainfo.sType					= VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
		vkdsainfo.pNext					= nullptr;
		vkdsainfo.descriptorPool		= vkdsp;
		vkdsainfo.descriptorSetCount	= 1;
		vkdsainfo.pSetLayouts			= &dsl;

	VkDescriptorSetAllocateInfo vkdsainfo2;
		vkdsainfo2.sType				= VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
		vkdsainfo2.pNext				= nullptr;
		vkdsainfo2.descriptorPool		= vkdsp2;
		vkdsainfo2.descriptorSetCount	= 1;
		vkdsainfo2.pSetLayouts			= &dsl;

	VkDescriptorSet vkds;
	vkAllocateDescriptorSets(vk_ldv.ld, &vkdsainfo, &vkds);

	VkDescriptorSet vkds2;
	vkAllocateDescriptorSets(vk_ldv.ld, &vkdsainfo2, &vkds2);

	ov( "Test images ..." );

	const uint32_t LG = 32;

	VkExtent3D ext3d;
		ext3d.width 	= 512*1;
		ext3d.height 	= 512*1;
		ext3d.depth 	= 1;

	VkImageCreateInfo vkicinfo;
		vkicinfo.sType					= VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
		vkicinfo.pNext					= nullptr;
		vkicinfo.flags					= 0;
		vkicinfo.imageType				= VK_IMAGE_TYPE_2D;
		vkicinfo.format					= VK_FORMAT_R8_UNORM;
		vkicinfo.extent					= ext3d;
		vkicinfo.mipLevels				= 1;
		vkicinfo.arrayLayers			= 1;
		vkicinfo.samples				= VK_SAMPLE_COUNT_1_BIT;
		vkicinfo.tiling					= VK_IMAGE_TILING_LINEAR;
		vkicinfo.usage					= VK_IMAGE_USAGE_STORAGE_BIT;
		vkicinfo.sharingMode			= VK_SHARING_MODE_EXCLUSIVE;
		vkicinfo.queueFamilyIndexCount	= 0;
		vkicinfo.pQueueFamilyIndices	= nullptr;
		vkicinfo.initialLayout			= VK_IMAGE_LAYOUT_UNDEFINED;

	VkImage vkimg[3];
	vkCreateImage(vk_ldv.ld, &vkicinfo, nullptr, &vkimg[0]);
	vkCreateImage(vk_ldv.ld, &vkicinfo, nullptr, &vkimg[1]);
	vkCreateImage(vk_ldv.ld, &vkicinfo, nullptr, &vkimg[2]);

	VkMemoryRequirements vkmr[3];
	vkGetImageMemoryRequirements(vk_ldv.ld, vkimg[0], &vkmr[0]);
	vkGetImageMemoryRequirements(vk_ldv.ld, vkimg[1], &vkmr[1]);
	vkGetImageMemoryRequirements(vk_ldv.ld, vkimg[2], &vkmr[2]);

	VkMemoryAllocateInfo vkmainfo[3];

		vkmainfo[0].sType				= VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
		vkmainfo[0].pNext				= nullptr;
		vkmainfo[0].allocationSize		= vkmr[0].size;
		vkmainfo[0].memoryTypeIndex		= findProperties(
											&vk_pdv[vk_ctx.pd_index].pd_memos,
											vkmr[0].memoryTypeBits,
											VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT | VK_MEMORY_PROPERTY_HOST_CACHED_BIT );

		vkmainfo[1].sType				= VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
		vkmainfo[1].pNext				= nullptr;
		vkmainfo[1].allocationSize		= vkmr[1].size;
		vkmainfo[1].memoryTypeIndex		= findProperties(
											&vk_pdv[vk_ctx.pd_index].pd_memos,
											vkmr[1].memoryTypeBits,
											VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT | VK_MEMORY_PROPERTY_HOST_CACHED_BIT );

		vkmainfo[2].sType				= VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
		vkmainfo[2].pNext				= nullptr;
		vkmainfo[2].allocationSize		= vkmr[2].size;
		vkmainfo[2].memoryTypeIndex		= findProperties(
											&vk_pdv[vk_ctx.pd_index].pd_memos,
											vkmr[2].memoryTypeBits,
											VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT | VK_MEMORY_PROPERTY_HOST_CACHED_BIT );

	VkDeviceMemory vkdm[3];
	vkAllocateMemory(vk_ldv.ld, &vkmainfo[0], nullptr, &vkdm[0]);
	vkAllocateMemory(vk_ldv.ld, &vkmainfo[1], nullptr, &vkdm[1]);
	vkAllocateMemory(vk_ldv.ld, &vkmainfo[2], nullptr, &vkdm[2]);

	vkBindImageMemory(vk_ldv.ld, vkimg[0], vkdm[0], 0);
	vkBindImageMemory(vk_ldv.ld, vkimg[1], vkdm[1], 0);
	vkBindImageMemory(vk_ldv.ld, vkimg[2], vkdm[2], 0);

	void* pvoid_buffer_in;
	vkMapMemory(vk_ldv.ld, vkdm[0], 0, VK_WHOLE_SIZE, 0, &pvoid_buffer_in);

	void* pvoid_buffer_ki;
	vkMapMemory(vk_ldv.ld, vkdm[1], 0, VK_WHOLE_SIZE, 0, &pvoid_buffer_ki);

	void* pvoid_buffer_ko;
	vkMapMemory(vk_ldv.ld, vkdm[2], 0, VK_WHOLE_SIZE, 0, &pvoid_buffer_ko);

	VkComponentMapping vkcmap;
		vkcmap.r = VK_COMPONENT_SWIZZLE_IDENTITY;
		vkcmap.g = VK_COMPONENT_SWIZZLE_IDENTITY;
		vkcmap.b = VK_COMPONENT_SWIZZLE_IDENTITY;
		vkcmap.a = VK_COMPONENT_SWIZZLE_IDENTITY;

	VkImageSubresourceRange vkimgsr;
		vkimgsr.aspectMask		= VK_IMAGE_ASPECT_COLOR_BIT;
		vkimgsr.baseMipLevel	= 0;
		vkimgsr.levelCount		= 1;
		vkimgsr.baseArrayLayer	= 0;
		vkimgsr.layerCount		= 1;

	VkImageViewCreateInfo vkimvinfo[3];

		vkimvinfo[0].sType				= VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
		vkimvinfo[0].pNext				= nullptr;
		vkimvinfo[0].flags				= 0;
		vkimvinfo[0].image				= vkimg[0];
		vkimvinfo[0].viewType			= VK_IMAGE_VIEW_TYPE_2D;
		vkimvinfo[0].format				= vkicinfo.format;
		vkimvinfo[0].components			= vkcmap;
		vkimvinfo[0].subresourceRange	= vkimgsr;

		vkimvinfo[1].sType				= VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
		vkimvinfo[1].pNext				= nullptr;
		vkimvinfo[1].flags				= 0;
		vkimvinfo[1].image				= vkimg[1];
		vkimvinfo[1].viewType			= VK_IMAGE_VIEW_TYPE_2D;
		vkimvinfo[1].format				= vkicinfo.format;
		vkimvinfo[1].components			= vkcmap;
		vkimvinfo[1].subresourceRange	= vkimgsr;

		vkimvinfo[2].sType				= VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
		vkimvinfo[2].pNext				= nullptr;
		vkimvinfo[2].flags				= 0;
		vkimvinfo[2].image				= vkimg[2];
		vkimvinfo[2].viewType			= VK_IMAGE_VIEW_TYPE_2D;
		vkimvinfo[2].format				= vkicinfo.format;
		vkimvinfo[2].components			= vkcmap;
		vkimvinfo[2].subresourceRange	= vkimgsr;

	VkImageView	vkimv[3];
	vkCreateImageView(vk_ldv.ld, &vkimvinfo[0], nullptr, &vkimv[0]);
	vkCreateImageView(vk_ldv.ld, &vkimvinfo[1], nullptr, &vkimv[1]);
	vkCreateImageView(vk_ldv.ld, &vkimvinfo[2], nullptr, &vkimv[2]);

	VkDescriptorImageInfo vkdii[3];

		vkdii[0].sampler		= VK_NULL_HANDLE;
		vkdii[0].imageView		= vkimv[0];
		vkdii[0].imageLayout	= VK_IMAGE_LAYOUT_GENERAL;

		vkdii[1].sampler		= VK_NULL_HANDLE;
		vkdii[1].imageView		= vkimv[1];
		vkdii[1].imageLayout	= VK_IMAGE_LAYOUT_GENERAL;

		vkdii[2].sampler		= VK_NULL_HANDLE;
		vkdii[2].imageView		= vkimv[2];
		vkdii[2].imageLayout	= VK_IMAGE_LAYOUT_GENERAL;

	ov( "Uniform Buffer ..." ); 

	VkBufferCreateInfo vkubuf;
		vkubuf.sType 					= VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
		vkubuf.pNext 					= nullptr;
		vkubuf.flags 					= 0;
		vkubuf.size 					= sizeof(UB32_64);
		vkubuf.usage 					= VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT;
		vkubuf.sharingMode 				= VK_SHARING_MODE_EXCLUSIVE;
		vkubuf.queueFamilyIndexCount 	= 0;
		vkubuf.pQueueFamilyIndices 		= nullptr;

	VkBuffer vkUBuff;
		vkCreateBuffer( vk_ldv.ld, &vkubuf, nullptr, &vkUBuff );

	VkDescriptorBufferInfo vkdescbuffinfo;
		vkdescbuffinfo.buffer 	= vkUBuff;
		vkdescbuffinfo.offset 	= 0;
		vkdescbuffinfo.range 	= VK_WHOLE_SIZE;

	VkMemoryRequirements vkmr_ub;
	vkGetBufferMemoryRequirements(vk_ldv.ld, vkUBuff, &vkmr_ub);

	VkMemoryAllocateInfo vkmemallo_ub;
		vkmemallo_ub.sType				= VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
		vkmemallo_ub.pNext				= nullptr;
		vkmemallo_ub.allocationSize		= vkmr_ub.size;
		vkmemallo_ub.memoryTypeIndex	= findProperties(
											&vk_pdv[vk_ctx.pd_index].pd_memos,
											vkmr_ub.memoryTypeBits,
											VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT );

	VkDeviceMemory ubdevmem;
	vkAllocateMemory(vk_ldv.ld, &vkmemallo_ub, nullptr, &ubdevmem);

	vkBindBufferMemory( vk_ldv.ld, vkUBuff, ubdevmem, 0 );

	void* pvoid_ub;
	vkMapMemory(vk_ldv.ld, ubdevmem, 0, VK_WHOLE_SIZE, 0, &pvoid_ub);

	ov( "vkUpdateDescriptorSets ..." ); 

	VkWriteDescriptorSet wds[3];

		wds[0].sType 				= VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
		wds[0].pNext 				= nullptr;
		wds[0].dstSet 				= vkds;
		wds[0].dstBinding 			= 0;
		wds[0].dstArrayElement 		= 0;
		wds[0].descriptorCount 		= 1;
		wds[0].descriptorType 		= VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
		wds[0].pImageInfo 			= &vkdii[0];
		wds[0].pBufferInfo 			= nullptr;
		wds[0].pTexelBufferView 	= nullptr;

		wds[1].sType 				= VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
		wds[1].pNext 				= nullptr;
		wds[1].dstSet 				= vkds;
		wds[1].dstBinding 			= 1;
		wds[1].dstArrayElement 		= 0;
		wds[1].descriptorCount 		= 1;
		wds[1].descriptorType 		= VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
		wds[1].pImageInfo 			= &vkdii[1];
		wds[1].pBufferInfo 			= nullptr;
		wds[1].pTexelBufferView 	= nullptr;

		wds[2].sType 				= VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
		wds[2].pNext 				= nullptr;
		wds[2].dstSet 				= vkds;
		wds[2].dstBinding 			= 2;
		wds[2].dstArrayElement 		= 0;
		wds[2].descriptorCount 		= 1;
		wds[2].descriptorType 		= VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
		wds[2].pImageInfo 			= nullptr;
		wds[2].pBufferInfo 			= &vkdescbuffinfo;
		wds[2].pTexelBufferView 	= nullptr;

	vkUpdateDescriptorSets(vk_ldv.ld, 3, wds, 0, nullptr);

	ov( "vkUpdateDescriptorSets ..." ); 

	VkWriteDescriptorSet wds2[2];

		wds2[0].sType 				= VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
		wds2[0].pNext 				= nullptr;
		wds2[0].dstSet 				= vkds2;
		wds2[0].dstBinding 			= 0;
		wds2[0].dstArrayElement 	= 0;
		wds2[0].descriptorCount 	= 1;
		wds2[0].descriptorType 		= VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
		wds2[0].pImageInfo 			= &vkdii[1];
		wds2[0].pBufferInfo 		= nullptr;
		wds2[0].pTexelBufferView 	= nullptr;

		wds2[1].sType 				= VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
		wds2[1].pNext 				= nullptr;
		wds2[1].dstSet 				= vkds2;
		wds2[1].dstBinding 			= 1;
		wds2[1].dstArrayElement 	= 0;
		wds2[1].descriptorCount 	= 1;
		wds2[1].descriptorType 		= VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
		wds2[1].pImageInfo 			= &vkdii[2];
		wds2[1].pBufferInfo 		= nullptr;
		wds2[1].pTexelBufferView 	= nullptr;

		wds2[2].sType 				= VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
		wds2[2].pNext 				= nullptr;
		wds2[2].dstSet 				= vkds2;
		wds2[2].dstBinding 			= 2;
		wds2[2].dstArrayElement 	= 0;
		wds2[2].descriptorCount 	= 1;
		wds2[2].descriptorType 		= VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
		wds2[2].pImageInfo 			= nullptr;
		wds2[2].pBufferInfo 		= &vkdescbuffinfo;
		wds2[2].pTexelBufferView 	= nullptr;

	vkUpdateDescriptorSets(vk_ldv.ld, 3, wds2, 0, nullptr);

/*
	ov( "Test buffers ..." );
/*
	uint32_t res_x = 1024 * 1;
	uint32_t res_y = 1024 * 1;

	VkBufferCreateInfo vkbci[2];

		vkbci[0].sType					= VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
		vkbci[0].pNext					= nullptr;
		vkbci[0].flags					= 0;
		vkbci[0].size					= sizeof(uint32_t) * res_x * res_y * 4;
		vkbci[0].usage					= VK_BUFFER_USAGE_STORAGE_BUFFER_BIT;
		vkbci[0].sharingMode			= VK_SHARING_MODE_EXCLUSIVE;
		vkbci[0].queueFamilyIndexCount	= 0;
		vkbci[0].pQueueFamilyIndices	= nullptr;

		vkbci[1].sType					= VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
		vkbci[1].pNext					= nullptr;
		vkbci[1].flags					= 0;
		vkbci[1].size					= sizeof(uint32_t) * res_x * res_y * 4;
		vkbci[1].usage					= VK_BUFFER_USAGE_STORAGE_BUFFER_BIT;
		vkbci[1].sharingMode			= VK_SHARING_MODE_EXCLUSIVE;
		vkbci[1].queueFamilyIndexCount	= 0;
		vkbci[1].pQueueFamilyIndices	= nullptr;

	VkBuffer vkb[2];
	vkCreateBuffer(vk_ldv.ld, &vkbci[0], nullptr, &vkb[0] );
	vkCreateBuffer(vk_ldv.ld, &vkbci[1], nullptr, &vkb[1] );

	VkDescriptorBufferInfo vldbinfo[2];

		vldbinfo[0].buffer		= vkb[0];
		vldbinfo[0].offset		= 0;
		vldbinfo[0].range		= VK_WHOLE_SIZE;

		vldbinfo[1].buffer		= vkb[1];
		vldbinfo[1].offset		= 0;
		vldbinfo[1].range		= VK_WHOLE_SIZE;

	VkWriteDescriptorSet wds[2];

		wds[0].sType 				= VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
		wds[0].pNext 				= nullptr;
		wds[0].dstSet 				= vkds;
		wds[0].dstBinding 			= 0;
		wds[0].dstArrayElement 		= 0;
		wds[0].descriptorCount 		= 1;
		wds[0].descriptorType 		= VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
		wds[0].pImageInfo 			= nullptr;
		wds[0].pBufferInfo 			= &vldbinfo[0];
		wds[0].pTexelBufferView 	= nullptr;

		wds[1].sType 				= VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
		wds[1].pNext 				= nullptr;
		wds[1].dstSet 				= vkds;
		wds[1].dstBinding 			= 1;
		wds[1].dstArrayElement 		= 0;
		wds[1].descriptorCount 		= 1;
		wds[1].descriptorType 		= VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
		wds[1].pImageInfo 			= nullptr;
		wds[1].pBufferInfo 			= &vldbinfo[1];
		wds[1].pTexelBufferView 	= nullptr;

	VkMemoryRequirements vkmr[2];
	vkGetBufferMemoryRequirements(vk_ldv.ld, vkb[0], &vkmr[0]);
	vkGetBufferMemoryRequirements(vk_ldv.ld, vkb[1], &vkmr[1]);

	VkMemoryAllocateInfo vkmainfo[2];

		vkmainfo[0].sType				= VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
		vkmainfo[0].pNext				= nullptr;
		vkmainfo[0].allocationSize		= sizeof(uint32_t) * res_x * res_y * 4;
		vkmainfo[0].memoryTypeIndex		= findProperties(
											&vk_pdv[vk_ctx.pd_index].pd_memos,
											vkmr[0].memoryTypeBits,
											VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT
										|	VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT );

		vkmainfo[1].sType				= VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
		vkmainfo[1].pNext				= nullptr;
		vkmainfo[1].allocationSize		= sizeof(uint32_t) * res_x * res_y * 4;
		vkmainfo[1].memoryTypeIndex		= findProperties(
											&vk_pdv[vk_ctx.pd_index].pd_memos,
											vkmr[1].memoryTypeBits,
											VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT
										|	VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT );
	VkDeviceMemory vkdm[2];
	vkAllocateMemory(vk_ldv.ld, &vkmainfo[0], nullptr, &vkdm[0]);
	vkAllocateMemory(vk_ldv.ld, &vkmainfo[1], nullptr, &vkdm[1]);

	vkBindBufferMemory(vk_ldv.ld, vkb[0], vkdm[0], 0);
	vkBindBufferMemory(vk_ldv.ld, vkb[1], vkdm[1], 0);

	void* pvoid_buffer_in;
	vkMapMemory(vk_ldv.ld, vkdm[0], 0, VK_WHOLE_SIZE, 0, &pvoid_buffer_in);

	void* pvoid_buffer_out;
	vkMapMemory(vk_ldv.ld, vkdm[1], 0, VK_WHOLE_SIZE, 0, &pvoid_buffer_out);

	vkUpdateDescriptorSets(vk_ldv.ld, 2, wds, 0, nullptr);
*/
	ov( "Test pipeline ..." );

	VkPipelineLayoutCreateInfo vk_pipe_layout_compute_info;
		vk_pipe_layout_compute_info.sType					= VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
		vk_pipe_layout_compute_info.pNext					= nullptr;
		vk_pipe_layout_compute_info.flags					= 0;
		vk_pipe_layout_compute_info.setLayoutCount			= 1;
		vk_pipe_layout_compute_info.pSetLayouts				= &dsl;
		vk_pipe_layout_compute_info.pushConstantRangeCount	= 0;
		vk_pipe_layout_compute_info.pPushConstantRanges		= nullptr;

	VkPipelineLayout vk_layout_compute;
	vkCreatePipelineLayout( vk_ldv.ld, &vk_pipe_layout_compute_info, nullptr, &vk_layout_compute );

	VkPipelineShaderStageCreateInfo	pipe_compute_shader_info;
		pipe_compute_shader_info.sType					= VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
		pipe_compute_shader_info.pNext					= nullptr;
		pipe_compute_shader_info.flags					= 0;
		pipe_compute_shader_info.stage					= VK_SHADER_STAGE_COMPUTE_BIT;
		pipe_compute_shader_info.module					= vk_shader_compute;
		pipe_compute_shader_info.pName					= "main";
		pipe_compute_shader_info.pSpecializationInfo	= nullptr;

	VkComputePipelineCreateInfo pipe_compute_info;
		pipe_compute_info.sType 				= VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO;
		pipe_compute_info.pNext 				= nullptr;
		pipe_compute_info.flags 				= 0;
		pipe_compute_info.stage 				= pipe_compute_shader_info;
		pipe_compute_info.layout 				= vk_layout_compute;
		pipe_compute_info.basePipelineHandle 	= NULL;
		pipe_compute_info.basePipelineIndex 	= 0;

	VkPipeline vk_pipeline_compute;
	vkCreateComputePipelines( vk_ldv.ld, VK_NULL_HANDLE, 1, &pipe_compute_info, nullptr, &vk_pipeline_compute );

	pipe_compute_shader_info.module		= vk_shader_compute2;
	pipe_compute_info.stage 			= pipe_compute_shader_info;

	VkPipeline vk_pipeline_compute2;
	vkCreateComputePipelines( vk_ldv.ld, VK_NULL_HANDLE, 1, &pipe_compute_info, nullptr, &vk_pipeline_compute2 );



	ov( "Test record buffer ..." );

	VkImageMemoryBarrier vk_IMB_UND_to_GEN[3];

		vk_IMB_UND_to_GEN[0].sType					= VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
		vk_IMB_UND_to_GEN[0].pNext					= nullptr;
		vk_IMB_UND_to_GEN[0].srcAccessMask			= 0;
		vk_IMB_UND_to_GEN[0].dstAccessMask			= 0;
		vk_IMB_UND_to_GEN[0].oldLayout				= VK_IMAGE_LAYOUT_UNDEFINED;
		vk_IMB_UND_to_GEN[0].newLayout				= VK_IMAGE_LAYOUT_GENERAL;
		vk_IMB_UND_to_GEN[0].srcQueueFamilyIndex	= vk_cmd_init.qf_index;
		vk_IMB_UND_to_GEN[0].dstQueueFamilyIndex	= vk_cmd_init.qf_index;
		vk_IMB_UND_to_GEN[0].image					= vkimg[0];
		vk_IMB_UND_to_GEN[0].subresourceRange		= vkimgsr;

		vk_IMB_UND_to_GEN[1].sType					= VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
		vk_IMB_UND_to_GEN[1].pNext					= nullptr;
		vk_IMB_UND_to_GEN[1].srcAccessMask			= 0;
		vk_IMB_UND_to_GEN[1].dstAccessMask			= 0;
		vk_IMB_UND_to_GEN[1].oldLayout				= VK_IMAGE_LAYOUT_UNDEFINED;
		vk_IMB_UND_to_GEN[1].newLayout				= VK_IMAGE_LAYOUT_GENERAL;
		vk_IMB_UND_to_GEN[1].srcQueueFamilyIndex	= vk_cmd_init.qf_index;
		vk_IMB_UND_to_GEN[1].dstQueueFamilyIndex	= vk_cmd_init.qf_index;
		vk_IMB_UND_to_GEN[1].image					= vkimg[1];
		vk_IMB_UND_to_GEN[1].subresourceRange		= vkimgsr;

		vk_IMB_UND_to_GEN[2].sType					= VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
		vk_IMB_UND_to_GEN[2].pNext					= nullptr;
		vk_IMB_UND_to_GEN[2].srcAccessMask			= 0;
		vk_IMB_UND_to_GEN[2].dstAccessMask			= 0;
		vk_IMB_UND_to_GEN[2].oldLayout				= VK_IMAGE_LAYOUT_UNDEFINED;
		vk_IMB_UND_to_GEN[2].newLayout				= VK_IMAGE_LAYOUT_GENERAL;
		vk_IMB_UND_to_GEN[2].srcQueueFamilyIndex	= vk_cmd_init.qf_index;
		vk_IMB_UND_to_GEN[2].dstQueueFamilyIndex	= vk_cmd_init.qf_index;
		vk_IMB_UND_to_GEN[2].image					= vkimg[2];
		vk_IMB_UND_to_GEN[2].subresourceRange		= vkimgsr;

	vkBeginCommandBuffer( vk_cmd_init.cmd, &vk_cmd_init.begin_info );

	vkCmdPipelineBarrier(
		vk_cmd_init.cmd,
		VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
		VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
		0,
		0, NULL,
		0, NULL,
		3, vk_IMB_UND_to_GEN );

	vkEndCommandBuffer( vk_cmd_init.cmd );

	ov( "Test record buffer ..." );

	vkBeginCommandBuffer( vk_cmd.cmd, &vk_cmd.begin_info );

	vkCmdBindPipeline( vk_cmd.cmd, vk_cmd.bind_type, vk_pipeline_compute );

	vkCmdBindDescriptorSets( vk_cmd.cmd, vk_cmd.bind_type, vk_layout_compute, 0, 1, &vkds, 0, nullptr );

	vkCmdDispatch( vk_cmd.cmd, (ext3d.width)/LG, (ext3d.height)/LG, 1 );

	vkEndCommandBuffer( vk_cmd.cmd );

	ov( "Test record buffer ..." );

	vkBeginCommandBuffer( vk_cmd2.cmd, &vk_cmd2.begin_info );

	vkCmdBindPipeline( vk_cmd2.cmd, vk_cmd2.bind_type, vk_pipeline_compute2 );

	vkCmdBindDescriptorSets( vk_cmd2.cmd, vk_cmd2.bind_type, vk_layout_compute, 0, 1, &vkds2, 0, nullptr );

	vkCmdDispatch( vk_cmd2.cmd, (ext3d.width)/LG, (ext3d.height)/LG, 1 );

	vkEndCommandBuffer( vk_cmd2.cmd );


	ov( "Test queue submit ..." );
	VkQueue q;
	vkGetDeviceQueue( vk_ldv.ld, vk_cmd.qf_index, 0, &q );

	VkSubmitInfo sub;
		sub.sType					= VK_STRUCTURE_TYPE_SUBMIT_INFO;
		sub.pNext					= nullptr;
		sub.waitSemaphoreCount		= 0;
		sub.pWaitSemaphores			= nullptr;
		sub.pWaitDstStageMask		= nullptr;
		sub.commandBufferCount		= 1;
		sub.pCommandBuffers			= &vk_cmd.cmd;
		sub.signalSemaphoreCount	= 0;
		sub.pSignalSemaphores		= nullptr;

	VkSubmitInfo sub2;
		sub2.sType					= VK_STRUCTURE_TYPE_SUBMIT_INFO;
		sub2.pNext					= nullptr;
		sub2.waitSemaphoreCount		= 0;
		sub2.pWaitSemaphores		= nullptr;
		sub2.pWaitDstStageMask		= nullptr;
		sub2.commandBufferCount		= 1;
		sub2.pCommandBuffers		= &vk_cmd2.cmd;
		sub2.signalSemaphoreCount	= 0;
		sub2.pSignalSemaphores		= nullptr;

	VkSubmitInfo sub_init;
		sub_init.sType					= VK_STRUCTURE_TYPE_SUBMIT_INFO;
		sub_init.pNext					= nullptr;
		sub_init.waitSemaphoreCount		= 0;
		sub_init.pWaitSemaphores		= nullptr;
		sub_init.pWaitDstStageMask		= nullptr;
		sub_init.commandBufferCount		= 1;
		sub_init.pCommandBuffers		= &vk_cmd_init.cmd;
		sub_init.signalSemaphoreCount	= 0;
		sub_init.pSignalSemaphores		= nullptr;

	VkFenceCreateInfo fi;
		fi.sType = 	VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
		fi.pNext = 	nullptr;
		fi.flags = 	0;

	VkFence f;
	vkCreateFence( vk_ldv.ld, &fi, nullptr, &f);

/*
//	ABGR
	srand(time(0));

	uint32_t *buffer_float_in = new uint32_t[res_x * res_y * 4];
	for(int i = 0; i < res_x * res_y; i++) {
		buffer_float_in[i*4+0] = UINT32_MAX;
		buffer_float_in[i*4+1] = rand()%UINT32_MAX;
		buffer_float_in[i*4+2] = 0u;
		buffer_float_in[i*4+3] = 0u; }

	memcpy( pvoid_buffer_in, buffer_float_in, sizeof(uint32_t) * res_x * res_y * 4 );
*/

	UB32_64 ub;
	for(int i = 0; i < 64; i++) { ub.u32[i] = 0; }

	NS_Timer optime;

	optime = start_timer(optime);
	vkQueueSubmit( q, 1, &sub_init, f );
	while (true) {
		if( vkGetFenceStatus( vk_ldv.ld, f ) == VK_SUCCESS ) {
			vkResetFences( vk_ldv.ld, 1, &f );
			break; } }
	end_timer(optime, "init Time");

	uint32_t image_index = 7;

	std::string 		img_path = "";
//						img_path = "res/data/PGM_512x512/IMG" + std::to_string((rand()%45)) + ".PGM";
						img_path = "res/data/PGM_512x512/IMG" + std::to_string(image_index) + ".PGM";

	std::string cmd;
	cmd = "feh " + img_path + "&";
	system(cmd.c_str());

	std::this_thread::sleep_for(std::chrono::milliseconds(200));

	GLFWwindow* glfw_W;
	glfwWindowHint(GLFW_CLIENT_API,	GLFW_NO_API);
	glfwWindowHint(GLFW_RESIZABLE, 	GL_FALSE);
	glfw_W = glfwCreateWindow(512, 512, "a", NULL, NULL);

	VkSurfaceKHR glfw_surface;
	glfwCreateWindowSurface(vk_ctx.vi, glfw_W, NULL, &glfw_surface);

	uint32_t mx_last = 0;
	uint32_t my_last = 0;

	uint32_t reps = 0;

	uint32_t radius = 1;


//for( int reps = (512)*(255); reps < (512)*(256); reps++) {
do {
	bool step = false;

	clear_glfw_mouse(&glfw_mouse);
	glfwPollEvents();
	glfwSetCursorPosCallback 	( glfw_W, glfw_mousemove_event 	 );
	glfwSetMouseButtonCallback	( glfw_W, glfw_mouseclick_event	 );
	glfwSetScrollCallback		( glfw_W, glfw_mousescroll_event );

	if( glfw_mouse.button == 0
	&&	glfw_mouse.action == 1  ) { image_index = (image_index + 1) % 45; step = true; }
	
//	Mouse Wheel Up
	if( glfw_mouse.yoffset ==  1 ) {
		glfw_mouse.yoffset  =  0;
		radius += 1; step = true; }

//	Mouse Wheel Down
	if( glfw_mouse.yoffset == -1 ) {
		glfw_mouse.yoffset  =  0;
		radius -= 1; step = true; }

	radius = (radius < 1) ? 1 : radius;

	ub.u32[0] = radius;
	ub.u32[1] = uint32_t(glfw_mouse.xpos);
	ub.u32[2] = uint32_t(glfw_mouse.ypos);

	if( ub.u32[1] != mx_last
	||	ub.u32[2] != my_last
	||	step ) {

	mx_last = ub.u32[1];
	my_last = ub.u32[2];


	memcpy(pvoid_ub, &ub, sizeof(UB32_64));

	char buffer_testimg[ext3d.width][ext3d.height];

//	for(int i = 0; i < ext3d.width; i++) { for(int j = 0; j < ext3d.height; j++) { buffer_testimg[i][j] = UINT8_MAX; } }

//	if(reps == 0) 	{ 	img_path = "res/data/PGM_512x512/IMG1.PGM"; }
//	else 			{ 	img_path = "out/output/kernel_3x3/IMG" + std::to_string(reps-1) + ".PGM"; }

//				img_path = "out/output/kernel_3x3/IMG1.PGM";
	img_path = "res/data/PGM_512x512/IMG" + std::to_string(image_index) + ".PGM";
	std::ifstream fload_img(img_path.c_str(), std::ios::in | std::ios::binary);
		fload_img.seekg(0, fload_img.end);
		int f_len = fload_img.tellg();
		fload_img.seekg(f_len-sizeof(buffer_testimg));
		fload_img.read((char*)&buffer_testimg, sizeof(buffer_testimg));
	fload_img.close();

//	for(int i = 0; i < ext3d.width; i++) { for(int j = 0; j < ext3d.height; j++) { buffer_testimg[i][j] = UINT8_MAX; } }
	memcpy( pvoid_buffer_ki, buffer_testimg, sizeof(char) * ext3d.width * ext3d.height );


/*	for(int i = 0; i < 1; i++) {
		optime = start_timer(optime);
		vkQueueSubmit( q, 1, &sub, f );
		while (true) {
			if( vkGetFenceStatus( vk_ldv.ld, f ) == VK_SUCCESS ) {
				vkResetFences( vk_ldv.ld, 1, &f );
				break; } }
		end_timer(optime, "Queue Time"); }*/

	for(int i = 0; i < 1; i++) {
		optime = start_timer(optime);
		vkQueueSubmit( q, 1, &sub2, f );
		while (true) {
			if( vkGetFenceStatus( vk_ldv.ld, f ) == VK_SUCCESS ) {
				vkResetFences( vk_ldv.ld, 1, &f );
				break; } }
		end_timer(optime, "Queue Time"); }/**/

/*	std::string fname = "out/output/IMG" + std::to_string(0) + ".PGM";
	std::ofstream file(fname.c_str(), std::ios::out | std::ios::binary);
		file 	<< "P5" 		<< "\n"
			 	<< ext3d.width 	<< " "
			 	<< ext3d.height	<< "\n"
			 	<< "255"		<< "\n";
	file.write( (const char*)pvoid_buffer_in,  ext3d.width * ext3d.height );
	file.close();*/

/*	fname = "out/output/kernel_3x3/IMG" + std::to_string(0) + ".PGM";
	std::ofstream filek(fname.c_str(), std::ios::out | std::ios::binary);
		filek 	<< "P5" 				<< "\n"
			 	<< ext3d_ker.width   	<< " "
			 	<< ext3d_ker.height * ext3d_ker.depth		<< "\n"
			 	<< "255"				<< "\n";
	filek.write( (const char*)pvoid_buffer_ki, ext3d_ker.width * ext3d_ker.height * ext3d_ker.depth );
	filek.close();

	fname = "out/output/kernel_3x3/IMG" + std::to_string(1) + ".PGM";
	std::ofstream filek2(fname.c_str(), std::ios::out | std::ios::binary);
		filek2 	<< "P5" 				<< "\n"
			 	<< ext3d_ker.width   	<< " "
			 	<< ext3d_ker.height * ext3d_ker.depth		<< "\n"
			 	<< "255"				<< "\n";
	filek2.write( (const char*)pvoid_buffer_ko, ext3d_ker.width * ext3d_ker.height * ext3d_ker.depth );
	filek2.close();*/

	std::string fname = "out/output/ConvOut/IMG" + std::to_string(reps) + ".PGM";
	std::ofstream filek2(fname.c_str(), std::ios::out | std::ios::binary);
		filek2 	<< "P5" 				<< "\n"
			 	<< ext3d.width   		<< " "
			 	<< ext3d.height			<< "\n"
			 	<< "255"				<< "\n";
	filek2.write( (const char*)pvoid_buffer_ko, ext3d.width * ext3d.height );
	filek2.close();

/*	std::string fname2 = "out/output/ConvOut/feh.PGM";
	std::ofstream filek3(fname2.c_str(), std::ios::out | std::ios::binary);
		filek3 	<< "P5" 				<< "\n"
			 	<< ext3d_ker.width   	<< " "
			 	<< ext3d_ker.height		<< "\n"
			 	<< "255"				<< "\n";
	filek3.write( (const char*)pvoid_buffer_ko, ext3d_ker.width * ext3d_ker.height );
	filek3.close();*/

	std::this_thread::sleep_for(std::chrono::milliseconds(30));

	cmd = "feh " + fname + "&";
	system(cmd.c_str());

	std::this_thread::sleep_for(std::chrono::milliseconds(30));

	cmd = "pkill -TERM -f 'feh .*IMG" + std::to_string(reps-4) + "'";
	system(cmd.c_str());

	std::this_thread::sleep_for(std::chrono::milliseconds(30));

	ub.u32[63]++;
	reps++;
	}
} while ( !glfwWindowShouldClose(glfw_W) );

	ov( "done" );

	ov( "EXIT" );
		engine_vulkan_context_exit( &vk_ctx, &vk_ldv, vk_cpl );

	cmd = "killall 'feh'";
	system(cmd.c_str());

	return 0;
}








